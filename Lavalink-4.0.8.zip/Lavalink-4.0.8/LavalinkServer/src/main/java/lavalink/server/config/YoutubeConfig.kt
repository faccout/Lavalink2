package lavalink.server.config

data class YoutubeConfig(
    var email: String = "",
    var password: String = ""
)